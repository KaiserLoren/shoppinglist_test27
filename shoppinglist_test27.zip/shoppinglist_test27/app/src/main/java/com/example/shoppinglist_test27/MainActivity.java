package com.example.shoppinglist_test27;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private ArrayList<String> shoppingLists;
    private ArrayAdapter<String> adapter;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        shoppingLists = new ArrayList<>();
        listView = findViewById(R.id.listView);
        FloatingActionButton fab = findViewById(R.id.fab);



        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, shoppingLists);
        listView.setAdapter(adapter);
        loadShoppingLists();

        fab.setOnClickListener(v -> {
            // Yeni liste ekleme işlemi
            long id = dbHelper.addShoppingList("Yeni Liste");
            if (id != -1) {
                Toast.makeText(this, "Liste eklendi!", Toast.LENGTH_SHORT).show();
                loadShoppingLists();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            // Listeye ait öğeleri aç
            Intent intent = new Intent(MainActivity.this, ItemsActivity.class);
            intent.putExtra("listId", id);
            startActivity(intent);
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            // Listeyi sil
            dbHelper.removeShoppingList(id);
            loadShoppingLists();
            return true;
        });
    }

    private void loadShoppingLists() {
        shoppingLists.clear();
        Cursor cursor = dbHelper.getAllShoppingLists();
        while (cursor.moveToNext()) {
            shoppingLists.add(cursor.getString(cursor.getColumnIndexOrThrow("list_name")));
        }
        adapter.notifyDataSetChanged();
    }

}
