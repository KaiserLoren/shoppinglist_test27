package com.example.shoppinglist_test27;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ShoppingApp.db";
    private static final int DATABASE_VERSION = 1;

    // Shopping Lists Table
    private static final String TABLE_SHOPPING_LISTS = "shopping_lists";
    private static final String COLUMN_LIST_ID = "list_id";
    private static final String COLUMN_LIST_NAME = "list_name";

    // Items Table
    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_QUANTITY = "item_quantity";
    private static final String COLUMN_ITEM_LIST_ID = "list_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create shopping lists table
        String createShoppingListsTable = "CREATE TABLE " + TABLE_SHOPPING_LISTS + " (" +
                COLUMN_LIST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_LIST_NAME + " TEXT NOT NULL)";
        db.execSQL(createShoppingListsTable);

        // Create items table
        String createItemsTable = "CREATE TABLE " + TABLE_ITEMS + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_ITEM_QUANTITY + " INTEGER NOT NULL, " +
                COLUMN_ITEM_LIST_ID + " INTEGER NOT NULL, " +
                "FOREIGN KEY(" + COLUMN_ITEM_LIST_ID + ") REFERENCES " + TABLE_SHOPPING_LISTS + "(" + COLUMN_LIST_ID + "))";
        db.execSQL(createItemsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SHOPPING_LISTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // Add a new shopping list
    public long addShoppingList(String listName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_LIST_NAME, listName);
        return db.insert(TABLE_SHOPPING_LISTS, null, values);
    }

    // Add an item to a list
    public long addItemToList(String itemName, int quantity, long listId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_LIST_ID, listId);
        return db.insert(TABLE_ITEMS, null, values);
    }

    // Get all shopping lists
    public Cursor getAllShoppingLists() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_SHOPPING_LISTS, null);
    }

    // Get all items for a specific list
    public Cursor getItemsForList(long listId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ITEMS + " WHERE " + COLUMN_ITEM_LIST_ID + " = ?", new String[]{String.valueOf(listId)});
    }

    // Remove a shopping list
    public void removeShoppingList(long listId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ITEMS, COLUMN_ITEM_LIST_ID + " = ?", new String[]{String.valueOf(listId)});
        db.delete(TABLE_SHOPPING_LISTS, COLUMN_LIST_ID + " = ?", new String[]{String.valueOf(listId)});
    }

    // Remove an item from a list
    public void removeItem(long itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ITEMS, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
    }
}

