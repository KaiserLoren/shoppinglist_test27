package com.example.shoppinglist_test27;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ItemsActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private ArrayList<String> items;
    private ArrayList<Long> itemIds;
    private ArrayAdapter<String> adapter;
    private ListView listView;
    private long listId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        dbHelper = new DatabaseHelper(this);
        items = new ArrayList<>();
        itemIds = new ArrayList<>();
        listView = findViewById(R.id.listView);
        FloatingActionButton fab = findViewById(R.id.fab); // FAB eklenmeli

        listId = getIntent().getLongExtra("listId", -1);


        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

        // Yeni öğe eklemek için FAB tıklama olayı
        fab.setOnClickListener(view -> showAddItemDialog());
    }

    private void loadItems() {
        items.clear();
        itemIds.clear();
        Cursor cursor = dbHelper.getItemsForList(listId);
        while (cursor.moveToNext()) {
            items.add(cursor.getString(cursor.getColumnIndexOrThrow("item_name")));
            itemIds.add(cursor.getLong(cursor.getColumnIndexOrThrow("item_id")));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Item");
        builder.setMessage("Enter item name and quantity:");

        // Özel bir giriş kutusu tasarımı için
        builder.setView(R.layout.dialog_add_item); // Özel bir XML dosyası (dialog_add_item.xml) kullanabilirsiniz

        builder.setPositiveButton("Add", (dialog, which) -> {
            // Burada, kullanıcıdan öğe adı ve miktarını alın
            String itemName = "Example Item"; // Kullanıcıdan alınacak
            int quantity = 1; // Kullanıcıdan alınacak
            listView.setOnItemLongClickListener((parent, view, position, id) -> {
                long itemId = itemIds.get(position); // Tıklanan öğenin ID'sini al
                dbHelper.removeItem(itemId); // Veritabanından öğeyi kaldır
                items.remove(position); // Listeden öğeyi kaldır
                itemIds.remove(position); // ID'yi listeden kaldır
                adapter.notifyDataSetChanged(); // Görünümü güncelle
                Toast.makeText(this, "Item removed", Toast.LENGTH_SHORT).show();
                return true;
            });
            long itemId = dbHelper.addItemToList(itemName, quantity, listId);
            if (itemId != -1) {
                items.add(itemName);
                itemIds.add(itemId);
                adapter.notifyDataSetChanged();
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }

        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}